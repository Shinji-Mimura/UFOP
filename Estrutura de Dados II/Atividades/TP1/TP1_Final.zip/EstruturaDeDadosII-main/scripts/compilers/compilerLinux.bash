#!/bin/bash

cd ../../src/

rm pesquisa

gcc *.c -o pesquisa -Wall

rm  *.bin
