#!/bin/bash

gcc main.c -o main
./main
